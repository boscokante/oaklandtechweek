import React from "react";
import HiiiWAVButton from "../components/HiiiWAVButton";
import HiiiWAVSection from "../components/HiiiWAVSection";
import "../css/hiiiwav.css";

export default function Example() {
  return (
    <main className="font-hiiiwav">
      <header className="hiiiwav-hero hiiiwav-bg-orange">
        <h1 className="hiiiwav-heading text-6xl">WHERE BLACK ARTISTS CREATE WITHOUT LIMITS</h1>
      </header>

      <HiiiWAVSection bg="purple">
        <p className="hiiiwav-body max-w-2xl">
          HiiiWAV emerges from a rich history of creators and collaborators. We use bold, modern type and vibrant, digital-first colors.
        </p>
        <div className="mt-6 flex gap-4">
          <HiiiWAVButton variant="black">Get Involved</HiiiWAVButton>
          <HiiiWAVButton variant="green">Learn More</HiiiWAVButton>
        </div>
      </HiiiWAVSection>
    </main>
  );
}
