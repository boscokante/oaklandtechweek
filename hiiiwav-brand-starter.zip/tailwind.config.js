/** Tailwind preset for HiiiWAV */
/** Usage: import this file or paste the `theme` into your tailwind.config.{js,ts} */
module.exports = {
  content: ["./**/*.{ts,tsx,js,jsx,html}"],
  theme: {
    extend: {
      colors: {
        hiiiwav: {
          purple: "var(--hiiiwav-purple)",
          orange: "var(--hiiiwav-orange)",
          green: "var(--hiiiwav-green)",
          black: "var(--hiiiwav-black)",
        },
      },
      fontFamily: {
        hiiiwav: ["var(--font-hiiiwav-primary)", "Inter", "Helvetica Neue", "Helvetica", "Arial", "ui-sans-serif", "system-ui"],
        hiiiwavSerif: ["var(--font-hiiiwav-secondary)", "Georgia", "Times New Roman", "serif"]
      },
      letterSpacing: {
        tightest: "-.04em",
      }
    }
  },
  plugins: [],
};
