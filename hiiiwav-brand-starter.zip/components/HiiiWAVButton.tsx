import React from "react";

type Props = React.ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: "purple" | "orange" | "green" | "black" | "ghost";
};

export default function HiiiWAVButton({ variant = "black", className = "", children, ...rest }: Props) {
  const base = "inline-flex items-center justify-center rounded-2xl px-5 py-3 text-sm font-bold uppercase tracking-wide transition-transform active:scale-95";
  const styles: Record<string, string> = {
    purple: "bg-[var(--hiiiwav-purple)] text-black",
    orange: "bg-[var(--hiiiwav-orange)] text-black",
    green:  "bg-[var(--hiiiwav-green)] text-black",
    black:  "bg-[var(--hiiiwav-black)] text-white",
    ghost:  "bg-transparent border-2 border-black text-black"
  };

  return (
    <button className={[base, styles[variant], className].join(" ")} {...rest}>
      {children}
    </button>
  );
}
