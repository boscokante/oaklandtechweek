import React from "react";

type Props = React.HTMLAttributes<HTMLElement> & {
  bg?: "purple" | "orange" | "green" | "black";
  invertText?: boolean;
};

export default function HiiiWAVSection({ bg = "orange", invertText = false, className = "", children, ...rest }: Props) {
  return (
    <section
      className={[
        "rounded-3xl p-8 md:p-16 my-8",
        bg === "purple" ? "bg-[var(--hiiiwav-purple)]" : "",
        bg === "orange" ? "bg-[var(--hiiiwav-orange)]" : "",
        bg === "green"  ? "bg-[var(--hiiiwav-green)]"  : "",
        bg === "black"  ? "bg-[var(--hiiiwav-black)]"  : "",
        invertText ? "text-white" : "text-black",
        className
      ].join(" ")}
      {...rest}
    >
      {children}
    </section>
  );
}
