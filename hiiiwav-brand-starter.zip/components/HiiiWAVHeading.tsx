import React from "react";

type Props = React.HTMLAttributes<HTMLHeadingElement> & {
  as?: "h1"|"h2"|"h3"|"h4";
  emphasis?: boolean;
};

export default function HiiiWAVHeading({ as = "h1", emphasis = false, className = "", children, ...rest }: Props) {
  const Comp = as as any;
  return (
    <Comp
      className={
        [
          "font-hiiiwav font-bold uppercase tracking-tightest",
          as === "h1" ? "text-6xl" : as === "h2" ? "text-4xl" : as === "h3" ? "text-2xl" : "text-xl",
          className
        ].join(" ")
      }
      {...rest}
    >
      {children}
      {emphasis && <span className="font-hiiiwavSerif italic ml-2">{/* secondary italic for emphasis */}</span>}
    </Comp>
  );
}
