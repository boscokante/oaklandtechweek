# HiiiWAV Brand Starter (for Cursor / React / Tailwind)

This folder contains design tokens, Tailwind theme, CSS variables, example components, and SVG patterns so you can build a site in Cursor without relying on the original PDF.

## Quick start
1. Copy this folder into your project (or unzip into the repo root).
2. Add `@import "./css/hiiiwav.css";` to your global stylesheet.
3. Merge `tailwind.config.js` into your Tailwind config (or replace and tweak `content` globs).
4. Use the components inside `components/` and the patterns in `public/patterns/`.
5. Replace font variable values with your licensed font files (see below).

## Colors
- Purple `#A34DFF`
- Orange `#FF4D16`
- Green  `#99FF69`
- Black  `#000000`

> Patterns should be black bars over a single brand color background.

## Typography
- Primary: **PP Neue Montreal** (Book 400, Bold 700). All-caps bold for short headlines; Book for body.
- Secondary: **PP Editorial New Italic**. Use sparingly for emphasis; never alone.
- System fallbacks are included.

## Logo + Avatar guidance
- Use black or white only. Minimum width 25px. Never stretch/rotate/recolor. Use the triple-`i` avatar in familiar contexts.

## Fonts
Due to licensing, fonts are **not** included. Suggested setup with local font files:

```css
@font-face {
  font-family: "PP Neue Montreal";
  src: url("/fonts/PPNeueMontreal-Book.woff2") format("woff2");
  font-weight: 400;
  font-style: normal;
  font-display: swap;
}
@font-face {
  font-family: "PP Neue Montreal";
  src: url("/fonts/PPNeueMontreal-Bold.woff2") format("woff2");
  font-weight: 700;
  font-style: normal;
  font-display: swap;
}
@font-face {
  font-family: "PP Editorial New";
  src: url("/fonts/PPEditorialNew-Italic.woff2") format("woff2");
  font-weight: 400;
  font-style: italic;
  font-display: swap;
}
```

Then update CSS variables:
```css
:root{
  --font-hiiiwav-primary: "PP Neue Montreal";
  --font-hiiiwav-secondary: "PP Editorial New";
}
```

## Example
View `examples/Example.tsx` for a quick section/hero using the palette, type, and tone.

---

This starter translates the PDF's guidance (colors, type, logo rules, patterns, photography tone) into code and assets suitable for an IDE workflow.
